﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prak11_2
{
    public class kopmleks
    {
        private double a1;
        private double a2;
        private double b1;
        private double b2;
        private double z1;
        private double z2;
        private double z3;
        private double z4;
        private double r;
        private double s;

        public double A1 
        {
            get { return a1; }
            set { a1 = value; }
        }
        public double A2 
        {
            get { return a2; }
            set { a2 = value; }
        }
        public double B1 
        {
            get { return b1; }
            set { b1 = value; }
        }
        public double B2 
        {
            get { return b2; }
            set { b2 = value; }
        }
        public double Z1 
        {
            get { return z1; }
            set { z1 = value; }
        }
        public double Z2 
        {
            get { return z2; }
            set { z2 = value; }
        }
        public double Z3 
        {
            get { return z3; }
            set { z3 = value; }
        }
        public double Z4 
        {
            get { return z4; }
            set { z4 = value; }
        }
        public double R 
        {
            get { return r; }
            set { r = value; }
        }
        public double S 
        {
            get { return s; }
            set { s = value; }
        }
    }
}
