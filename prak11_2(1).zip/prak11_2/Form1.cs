﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prak11_2
{
    public partial class Form1 :Form
    {
        public Form1 ()
        {
            InitializeComponent();
        }

        private void Form1_Load (object sender, EventArgs e)
        {
            if (!radioButton6.Checked) 
            {
                powlab.Visible = false;
                pow.Visible = false;
            }
        }

        private void button1_Click (object sender, EventArgs e)
        {
            if (radioButton1.Checked || radioButton2.Checked || radioButton3.Checked || radioButton4.Checked)
            {
                try
                {

                    kopmleks KopmleksObj = new kopmleks();
                    KopmleksObj.A1 = Convert.ToDouble(textBox1.Text);
                    KopmleksObj.A2 = Convert.ToDouble(textBox3.Text);
                    KopmleksObj.B1 = Convert.ToDouble(textBox2.Text);
                    KopmleksObj.B2 = Convert.ToDouble(textBox4.Text);




                    if (radioButton1.Checked)
                    {
                        KopmleksObj.Z1 = KopmleksObj.A1 + KopmleksObj.A2;
                        KopmleksObj.Z2 = KopmleksObj.B1 + KopmleksObj.B2;
                        if (KopmleksObj.Z2 < 0)
                        {
                            MessageBox.Show($"вы выбрали {radioButton1.Text}; z3 = {KopmleksObj.Z1}{KopmleksObj.Z2}j");
                        }
                        else
                        {
                            MessageBox.Show($"вы выбрали {radioButton1.Text}; z3 = {KopmleksObj.Z1}+{KopmleksObj.Z2}j");
                        }
                    }

                    else if (radioButton2.Checked)
                    {
                        KopmleksObj.Z1 = KopmleksObj.A1 - KopmleksObj.A2;
                        KopmleksObj.Z2 = KopmleksObj.B1 - KopmleksObj.B2;
                        if (KopmleksObj.Z2 < 0)
                        {
                            MessageBox.Show($"вы выбрали {radioButton2.Text}; z3 = {KopmleksObj.Z1}{KopmleksObj.Z2}j");
                        }
                        else
                        {
                            MessageBox.Show($"вы выбрали {radioButton2.Text}; z3 = {KopmleksObj.Z1}+{KopmleksObj.Z2}j");
                        }
                    }

                    else if (radioButton3.Checked)
                    {
                        KopmleksObj.Z1 = KopmleksObj.A1 * KopmleksObj.A2;
                        KopmleksObj.Z2 = KopmleksObj.B1 * KopmleksObj.B2;
                        KopmleksObj.Z3 = KopmleksObj.A1 * KopmleksObj.B2;
                        KopmleksObj.Z4 = KopmleksObj.B1 * KopmleksObj.A2;
                        MessageBox.Show($" z1 = {KopmleksObj.Z1}; z2 = {KopmleksObj.Z2}; z3 = {KopmleksObj.Z3}; z4 = {KopmleksObj.Z4}");
                        KopmleksObj.Z1 = KopmleksObj.Z1 - KopmleksObj.Z2;
                        KopmleksObj.Z2 = KopmleksObj.Z3 + KopmleksObj.Z4;
                        if (KopmleksObj.Z2 > 0)
                        {
                            if (KopmleksObj.B1 > 0 || KopmleksObj.B2 > 0)
                            {
                                MessageBox.Show($"вы выбрали {radioButton3.Text}; z3 = {KopmleksObj.Z1}+{KopmleksObj.Z2}j");
                            }
                        }
                        else
                        {
                            MessageBox.Show($"вы выбрали {radioButton3.Text}; z3 = {KopmleksObj.Z1}{KopmleksObj.Z2}j");
                        }
                    }

                    else if (radioButton4.Checked)
                    {
                        KopmleksObj.Z1 = KopmleksObj.A1 * KopmleksObj.A2 + KopmleksObj.B1 * KopmleksObj.B2;
                        KopmleksObj.Z3 = KopmleksObj.B1 * KopmleksObj.A2 - KopmleksObj.A1 * KopmleksObj.B2;
                        KopmleksObj.Z2 = Math.Pow(KopmleksObj.A2, 2) + Math.Pow(KopmleksObj.B2, 2);
                        if (KopmleksObj.Z3 > 0)
                        {
                            MessageBox.Show($"вы выбрали {radioButton4.Text}; z3 = {KopmleksObj.Z1}+{KopmleksObj.Z3}j/{KopmleksObj.Z2}");
                        }
                        else MessageBox.Show($"вы выбрали {radioButton4.Text}; z3 = {KopmleksObj.Z1}{KopmleksObj.Z3}j/{KopmleksObj.Z2}");
                    }
                }
                catch { MessageBox.Show("входная строка имела неверный формат"); }
            }

            else
            {
                try
                {
                    kopmleks KopmleksObj = new kopmleks();
                    KopmleksObj.A1 = Convert.ToDouble(textBox1.Text);
                    KopmleksObj.B1 = Convert.ToDouble(textBox2.Text);
                    if (radioButton5.Checked)
                    {
                        KopmleksObj.Z1 = KopmleksObj.B1 * (-1);
                        if (KopmleksObj.B1 > 0)
                        {
                            MessageBox.Show($"вы выбрали {radioButton5.Text}; z3 = {KopmleksObj.A1}+{KopmleksObj.B1}j");
                        }
                        else MessageBox.Show($"вы выбрали {radioButton5.Text}; z3 = {KopmleksObj.A1}{KopmleksObj.B1}j");
                    }

                    else if (radioButton6.Checked)
                    {
                        KopmleksObj.R = Math.Sqrt(Math.Pow(KopmleksObj.A1,2)+Math.Pow(KopmleksObj.B1,2));
                        KopmleksObj.R = Math.Pow(KopmleksObj.R, KopmleksObj.S);
                        KopmleksObj.Z1 = KopmleksObj.A1/KopmleksObj.R;
                        KopmleksObj.Z2 = KopmleksObj.B1/ KopmleksObj.R;
                        MessageBox.Show($"вы выбрали {radioButton6.Text}; z3 = {Math.Round(KopmleksObj.R,2)}(cos({Math.Round(KopmleksObj.Z1,2)}) + j*sin({Math.Round(KopmleksObj.Z2,2)}))");
                    }

                    else if (radioButton7.Checked)
                    {
                        KopmleksObj.R = Math.Sqrt(Math.Pow(KopmleksObj.A1, 2) + Math.Pow(KopmleksObj.B1, 2));
                        KopmleksObj.Z1 = (KopmleksObj.R + KopmleksObj.A1)/KopmleksObj.S;
                        KopmleksObj.Z2 = (KopmleksObj.R - KopmleksObj.A1) / KopmleksObj.S;
                        KopmleksObj.R = Math.Pow(KopmleksObj.R, 1 / KopmleksObj.S);
                        if (KopmleksObj.B1 >= 0)
                        {
                            MessageBox.Show($"вы выбрали {radioButton6.Text}; z3 = {Math.Round(KopmleksObj.R, 2)}(cos({Math.Round(KopmleksObj.Z1, 2)}) + j*{KopmleksObj.B1/Math.Abs(KopmleksObj.B1)}*sin({Math.Round(KopmleksObj.Z2, 2)}))");
                        }
                    }
                }
                catch { MessageBox.Show("входная строка имела неверный формат"); }
            }


        }
        private void radioButton1_CheckedChanged (object sender, EventArgs e)
        {
            this.textBox3.Enabled = false;
            this.textBox4.Enabled = false;
            RadioButton radioButton1 = (RadioButton)sender;
            if (radioButton1.Checked.Equals(true))
            {
                this.textBox3.Enabled = true;
                this.textBox4.Enabled = true;
            }
        }

        private void radioButton2_CheckedChanged (object sender, EventArgs e)
        {
            this.textBox3.Enabled = false;
            this.textBox4.Enabled = false;
            RadioButton radioButton2 = (RadioButton) sender;
            if (radioButton2.Checked.Equals(true))
            {
                this.textBox3.Enabled = true;
                this.textBox4.Enabled = true;
            }
        }

        private void radioButton3_CheckedChanged (object sender, EventArgs e)
        {
            this.textBox3.Enabled = false;
            this.textBox4.Enabled = false;
            RadioButton radioButton3 = (RadioButton) sender;
            if (radioButton3.Checked.Equals(true))
            {
                this.textBox3.Enabled = true;
                this.textBox4.Enabled = true;
            }
        }

        private void radioButton4_CheckedChanged (object sender, EventArgs e)
        {
            this.textBox3.Enabled = false;
            this.textBox4.Enabled = false;
            RadioButton radioButton4 = (RadioButton) sender;
            if (radioButton4.Checked.Equals(true))
            {
                this.textBox3.Enabled = true;
                this.textBox4.Enabled = true;
            }
        }

        private void radioButton5_CheckedChanged (object sender, EventArgs e)
        {
            this.textBox3.Enabled = false;
            this.textBox4.Enabled = false;
            RadioButton radioButton5 = (RadioButton) sender;
        }

        private void radioButton6_CheckedChanged (object sender, EventArgs e)
        {
            this.textBox3.Enabled = false;
            this.textBox4.Enabled = false;
            powlab.Visible = false;
            pow.Visible = false;
            RadioButton radioButton6 = (RadioButton) sender;
            if (radioButton6.Checked.Equals(true))
            {
                powlab.Visible = true;
                pow.Visible = true;
            }
        }

        private void radioButton7_CheckedChanged (object sender, EventArgs e)
        {
            this.textBox3.Enabled = false;
            this.textBox4.Enabled = false;
            powlab.Visible = false;
            pow.Visible = false;
            RadioButton radioButton7 = (RadioButton) sender;
            if (radioButton6.Checked.Equals(true))
            {
                powlab.Visible = true;
                pow.Visible = true;
            }
        }
    }
}
